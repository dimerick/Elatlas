@extends('new/template')

@section('title')
    Inicio
@endsection

@section('content')
    <div class="panel panel-default">
        <div class="panel-heading"> <h4>Atlas del afecto</h4></div>
        <div class="panel-body">
            <img width="100%" src="/files/fotos_perfil/fto.jpg">
            <div class="clearfix"></div>
            <hr>

            <p>Descripcion Grupo</p>

            <hr>


        </div>
    </div>

    <div class="panel panel-default">
        <div class="panel-heading"> <h4>Atlas del afecto</h4></div>
        <div class="panel-body">
            <img width="100%" src="/files/fotos_perfil/fto.jpg">
            <div class="clearfix"></div>
            <hr>

            <p>Descripcion Grupo</p>

            <hr>


        </div>
    </div>
@endsection