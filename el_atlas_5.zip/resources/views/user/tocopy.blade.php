@extends('plantilla')

@section('title')
    Quienes somos
@endsection

@section('css')

@endsection

@section('top-bar')
    @include('partials.top-bar-user')
@endsection


@section('pagina')
    Quienes somos
    @endsection

@section('content')

@endsection

@section('scripts')

@endsection