@extends('v2/template')

@section('title')
    Mapa Grupos
@endsection

@section('css')
    <link href="{{ asset('assets/v2/css/map.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/v2/css/Control.FullScreen.css') }}" rel="stylesheet">
@endsection

@section('content')
<input type="hidden" id="page-active" for="#li-groups">
    <div id="v2-map">

    </div>

@endsection

@section('scripts')
    <script src="{{ asset('assets/v2/js/mapGroups.js') }}"></script>
    <script src="{{ asset('assets/v2/js/Control.FullScreen.js') }}"></script>
@endsection