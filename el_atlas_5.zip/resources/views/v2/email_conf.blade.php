<p>Hola {{ $nombre }}, gracias por registrarte.</p>
<p>Para activar tu cuenta solo debes dar click en el siguiente link: </p>
<a href="{{"http://www.elatlas.org/active/".$cod_act}}">Activar Cuenta</a>





