@extends('v2/template-auth')

@section('title')
    Activacion Cuenta
@endsection


@section('content')
                    <div class="alert alert-danger">
                        <p>Codigo de activación no valido</p>
                        </div>
                    <div class="alert">
                    <p>Si tienes problemas para activar tu cuenta escribenos al email <b>info@elatlas.org</b></p>
                    </div>


@endsection