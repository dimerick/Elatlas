@extends('plantilla')

@section('title')
    Profile
@endsection

@section('pagina')
    Registro
    @endsection

    @section('content')
            <!-- BEGIN CONTENT WRAPPER -->
    <div class="content">
        <div class="container">
            <div class="row">

                <!-- BEGIN MAIN CONTENT -->
                <div class="main col-sm-6 col-sm-offset-3">


                </div>

            </div>
            <!-- END MAIN CONTENT -->

        </div>
    </div>
    </div>
    <!-- END CONTENT WRAPPER -->
@endsection