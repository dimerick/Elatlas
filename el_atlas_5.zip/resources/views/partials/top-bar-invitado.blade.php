<ul id="top-buttons">
    <li><a href="/auth/login"><i class="fa fa-sign-in"></i> Iniciar Sesion</a></li>
    <li><a href="/grupos/create"><i class="fa fa-pencil-square-o"></i> Registrarse</a></li>
    {{--<li class="divider"></li>--}}
    {{--<li>--}}
        {{--<div class="language-switcher">--}}
            {{--<span><i class="fa fa-globe"></i> Espa&ntilde;ol</span>--}}
            {{--<ul>--}}
                {{--<li><a href="#">English</a></li>--}}

            {{--</ul>--}}
        {{--</div>--}}
    {{--</li>--}}
</ul>