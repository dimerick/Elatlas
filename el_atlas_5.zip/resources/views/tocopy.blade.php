@extends('plantilla')

@section('title')
    Quienes somos
@endsection

@section('top-bar')
    @include('partials.top-bar-invitado')
@endsection


@section('pagina')
    Quienes somos
    @endsection

    @section('content')
            <!-- BEGIN CONTENT WRAPPER -->
    <div class="content">

    </div>
    <!-- END CONTENT WRAPPER -->
@endsection